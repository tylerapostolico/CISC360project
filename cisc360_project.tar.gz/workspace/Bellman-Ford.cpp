// #include <iostream>
// #include <fstream>
// #include <vector>
// #include <cassert>
// #include <limits>
// #include <iomanip>
// #include <climits>

// namespace std {   }
// using namespace std;

// struct edge
// {
//    size_t u, v;
//    long weight;
// };

// istream& operator>>(istream& is, edge& i)
// {
//    return is >> i.u >> i.v >> i.weight;
// }

// long bellman_ford(const vector<edge>& store, const size_t s, const size_t nodes, const long max_weight, bool& negative_cycle_detected)
// {
//    assert(s < nodes);

//    negative_cycle_detected = false;

//    vector<long> distance;
//                 distance.resize(nodes);

//    for (size_t i = 0; i < distance.size(); distance[i] = max_weight, ++i);

//    distance[s] = 0;

//    long result_min = 0;

//    for (size_t i = 0; i < (distance.size() - 1); ++i)
//    {
//       for (size_t j = 0; j < store.size(); ++j)
//       {
//          if ((distance[store[j].u] + store[j].weight) < distance[store[j].v])
//          {
//             distance[store[j].v] = distance[store[j].u] + store[j].weight;
//             result_min = min(distance[store[j].v], result_min);
//          }
//       }
//    }

//    for (size_t i = 0; i < store.size(); ++i)
//    {
//       if ((distance[store[i].u] + store[i].weight) < distance[store[i].v])
//       {
//          negative_cycle_detected = true;
//          break;
//       }
//    }

//    return result_min;
// }

// int main(int argc, char* argv[])
// {
//    vector<edge> store;
//    size_t nodes = 0, edges = 0;
//    long max_weight = LONG_MIN;

//    if (argc > 1)
//    {
//       ifstream ifs;
//                ifs.open(argv[1]);

//       ifs >> nodes >> edges;

//       edge e = {0};
//       while (ifs >> e)
//       {
//          --e.u;
//          --e.v;
//          store.push_back(e);
//          max_weight = max(max_weight, e.weight + 1);
//       }

//       ifs.close();
//    }

//    cout << "Input size: " << store.size() << endl;
//    assert(store.size() == edges);

//    long min_weight = max_weight;
//    bool abort = false;
//    for (size_t i = 0; i < nodes; ++i)
//    {
//       bool negative_cycle_detected = false;
//       long weight = bellman_ford(store, i, nodes, max_weight, negative_cycle_detected);

//       if (negative_cycle_detected == false)
//       {
//          cout << "Source: " << setw(4) << i << ", Weight: " << setw(4) << weight << endl;
//          min_weight = min(min_weight, weight);
//       }
//       else
//       {
//          cout << "Source: " << setw(4) << i << ", Negative Cycle Detected. No result. Aborting." << endl;
//          abort = true;
//          break;
//       }
//    }

//    if (abort == false)
//    {
//       cout << "Shortest shortest weight: " << setw(4) << min_weight << endl;
//    }

//    cin.get();

//    return 0;
// }
// //source: https://gist.github.com/TheRayTracer/4522782


// A C / C++ program for Bellman-Ford's single source 
// shortest path algorithm.
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
 
// a structure to represent a weighted edge in graph
struct Edge
{
    char src, dest, weight;
};
 
// a structure to represent a connected, directed and 
// weighted graph
struct Graph
{
    // V-> Number of vertices, E-> Number of edges
    int V, E;
 
    // graph is represented as an array of edges.
    struct Edge* edge;
};
 
// Creates a graph with V vertices and E edges
struct Graph* createGraph(int V, int E)
{
    struct Graph* graph = 
         (struct Graph*) malloc(sizeof(struct Graph) );
    graph->V = V;
    graph->E = E;
 
    graph->edge = 
       (struct Edge*) malloc( graph->E * sizeof( struct Edge ) );
 
    return graph;
}
 
// A utility function used to print the solution
void printArr(int dist[], int n)
{
    printf("Vertex   Distance from Source\n");
    for (int i = 0; i < n; ++i)
        printf("%d \t\t %d\n", i, dist[i]);
}
 
// The main function that finds shortest distances from src to
// all other vertices using Bellman-Ford algorithm.  The function
// also detects negative weight cycle

void BellmanFord(struct Graph* graph, int src)
{
    int V = graph->V;
    int E = graph->E;
    int dist[V];
 
    // Step 1: Initialize distances from src to all other vertices
    // as INFINITE
    for (int i = 0; i < V; i++)
        dist[i]   = INT_MAX;
    dist[src] = 0;
 
    // Step 2: Relax all edges |V| - 1 times. A simple shortest 
    // path from src to any other vertex can have at-most |V| - 1 
    // edges
    for (int i = 1; i <= V-1; i++)
    {
        for (int j = 0; j < E; j++)
        {
            int u = graph->edge[j].src;
            int v = graph->edge[j].dest;
            int weight = graph->edge[j].weight;
            if (dist[u] != INT_MAX && dist[u] + weight < dist[v])
                dist[v] = dist[u] + weight;
        }
    }
 
    // Step 3: check for negative-weight cycles.  The above step 
    // guarantees shortest distances if graph doesn't contain 
    // negative weight cycle.  If we get a shorter path, then there
    // is a cycle.
    for (int i = 0; i < E; i++)
    {
        int u = graph->edge[i].src;
        int v = graph->edge[i].dest;
        int weight = graph->edge[i].weight;
        if (dist[u] != INT_MAX && dist[u] + weight < dist[v])
            printf("Graph contains negative weight cycle");
    }
 
    printArr(dist, V);
 
    return;
}
 
// Driver program to test above functions
int main()
{
    /* Let us create the graph given in above example */
    int V = 20;  // Number of vertices in graph
    int E = 31;  // Number of edges in graph
    struct Graph* graph = createGraph(V, E);
 
   //edge 0-29, 31 total. please test these idk how atm. missed a node from h->m
//   graph->edge[0].src = 'A';
//   graph->edge[0].dest = 'B';
//   graph->edge[0].weight = 3;
   
//   graph->edge[1].src = 'A';
//   graph->edge[1].dest = 'C';
//   graph->edge[1].weight = 2;
   
//   graph->edge[2].src = 'A';
//   graph->edge[2].dest = 'T';
//   graph->edge[2].weight = 100;
   
//   graph->edge[3].src = 'B';
//   graph->edge[3].dest = 'H';
//   graph->edge[3].weight = 3;
   
//   graph->edge[4].src = 'B';
//   graph->edge[4].dest = 'I';
//   graph->edge[4].weight = 6;
   
//   graph->edge[5].src = 'C';
//   graph->edge[5].dest = 'E';
//   graph->edge[5].weight = 1;
   
//   graph->edge[6].src = 'D';
//   graph->edge[6].dest = 'J';
//   graph->edge[6].weight = 4;
   
//   graph->edge[7].src = 'E';
//   graph->edge[7].dest = 'G';
//   graph->edge[7].weight = 1;
   
//   graph->edge[8].src = 'F';
//   graph->edge[8].dest = 'L';
//   graph->edge[8].weight = 1;
   
//   graph->edge[9].src = 'G';
//   graph->edge[9].dest = 'L';
//   graph->edge[9].weight = 3;
   
//   graph->edge[10].src = 'G';
//   graph->edge[10].dest = 'P';
//   graph->edge[10].weight = 4;
   
//   graph->edge[11].src = 'H';
//   graph->edge[11].dest = 'E';
//   graph->edge[11].weight = 2;
   
//   graph->edge[12].src = 'H';
//   graph->edge[12].dest = 'I';
//   graph->edge[12].weight = 7;
   
//   graph->edge[13].src = 'I';
//   graph->edge[13].dest = 'D';
//   graph->edge[13].weight = 3;
   
//   graph->edge[14].src = 'I';
//   graph->edge[14].dest = 'N';
//   graph->edge[14].weight = 6;
   
//   graph->edge[15].src = 'I';
//   graph->edge[15].dest = 'J';
//   graph->edge[15].weight = 5;
   
//   graph->edge[16].src = 'J';
//   graph->edge[16].dest = 'K';
//   graph->edge[16].weight = 1;
   
//   graph->edge[17].src = 'J';
//   graph->edge[17].dest = 'O';
//   graph->edge[17].weight = 6;
   
//   graph->edge[18].src = 'K';
//   graph->edge[18].dest = 'O';
//   graph->edge[18].weight = 2;
   
//   graph->edge[19].src = 'L';
//   graph->edge[19].dest = 'P';
//   graph->edge[19].weight = 2;
   
//   graph->edge[20].src = 'M';
//   graph->edge[20].dest = 'Q';
//   graph->edge[20].weight = 1;
   
//   graph->edge[21].src = 'N';
//   graph->edge[21].dest = 'T';
//   graph->edge[21].weight = 1;
   
//   graph->edge[22].src = 'O';
//   graph->edge[22].dest = 'T';
//   graph->edge[22].weight = 3;
   
//   graph->edge[23].src = 'P';
//   graph->edge[23].dest = 'N';
//   graph->edge[23].weight = 1;
   
//   graph->edge[24].src = 'Q';
//   graph->edge[24].dest = 'N';
//   graph->edge[24].weight = 3;
   
//   graph->edge[25].src = 'Q';
//   graph->edge[25].dest = 'R';
//   graph->edge[25].weight = 2;
   
//   graph->edge[26].src = 'Q';
//   graph->edge[26].dest = 'S';
//   graph->edge[26].weight = 4;
   
//   graph->edge[27].src = 'R';
//   graph->edge[27].dest = 'M';
//   graph->edge[27].weight = 2;
   
//   graph->edge[28].src = 'S';
//   graph->edge[28].dest = 'T';
//   graph->edge[28].weight = 1;
   
//   graph->edge[29].src = 'T';
//   graph->edge[29].dest = 'A';
//   graph->edge[29].weight = 100;
   //graph 1 data
   graph->edge[0].src = 0;//a
   graph->edge[0].dest = 1;//b
   graph->edge[0].weight = 3;
   
   graph->edge[1].src = 0;//a
   graph->edge[1].dest = 2;//c
   graph->edge[1].weight = 2;
   
   graph->edge[2].src = 0;//a
   graph->edge[2].dest = 19;//t
   graph->edge[2].weight = 100;
   
   graph->edge[3].src = 2;//b
   graph->edge[3].dest = 7;//h
   graph->edge[3].weight = 3;
   
   graph->edge[4].src = 1;//b
   graph->edge[4].dest = 8;//i
   graph->edge[4].weight = 6;
   
   graph->edge[5].src = 2;//c
   graph->edge[5].dest = 4;//e
   graph->edge[5].weight = 1;
   
   graph->edge[6].src = 3;//d
   graph->edge[6].dest = 9;//j
   graph->edge[6].weight = 4;
   
   graph->edge[7].src = 4;//e
   graph->edge[7].dest = 6;//g
   graph->edge[7].weight = 1;
   
   graph->edge[8].src = 5;//f
   graph->edge[8].dest = 11;//l
   graph->edge[8].weight = 1;
   
   graph->edge[9].src = 6;//g
   graph->edge[9].dest = 11;//l
   graph->edge[9].weight = 3;
   
   graph->edge[3].src = 6;//g
   graph->edge[9].dest = 5;//f
   graph->edge[9].weight = 3;
   
   graph->edge[10].src = 6;//g
   graph->edge[10].dest = 15;//p
   graph->edge[10].weight = 4;
   
   graph->edge[11].src = 7;//h
   graph->edge[11].dest = 4;//e
   graph->edge[11].weight = 2;
   
   graph->edge[12].src = 7;//h
   graph->edge[12].dest = 8;//i
   graph->edge[12].weight = 7;
   
   graph->edge[13].src = 8;//i
   graph->edge[13].dest = 3;//d
   graph->edge[13].weight = 3;
   
   graph->edge[14].src = 8;//i
   graph->edge[14].dest = 13;//n
   graph->edge[14].weight = 6;
   
   graph->edge[15].src = 8;//i
   graph->edge[15].dest = 9;//j
   graph->edge[15].weight = 5;
   
   graph->edge[16].src = 9;//j
   graph->edge[16].dest = 10;//k
   graph->edge[16].weight = 1;
   
   graph->edge[17].src = 9;//j
   graph->edge[17].dest = 14;//o
   graph->edge[17].weight = 6;
   
   graph->edge[18].src = 10;//k
   graph->edge[18].dest = 14;//o
   graph->edge[18].weight = 2;
   
   graph->edge[19].src = 11;//l
   graph->edge[19].dest = 15;//p
   graph->edge[19].weight = 2;
   
   graph->edge[20].src = 12;//m
   graph->edge[20].dest = 16;//q
   graph->edge[20].weight = 1;
   
   graph->edge[21].src = 13;//n
   graph->edge[21].dest = 19;//t
   graph->edge[21].weight = 1;
   
   graph->edge[22].src = 14;//o
   graph->edge[22].dest = 19;//t
   graph->edge[22].weight = 3;
   
   graph->edge[23].src = 15;//p
   graph->edge[23].dest = 13;//n
   graph->edge[23].weight = 1;
   
   graph->edge[32].src = 15;//p
   graph->edge[32].dest = 7;//n
   graph->edge[32].weight = 1;
   
   graph->edge[24].src = 16;//q
   graph->edge[24].dest = 13;//n
   graph->edge[24].weight = 3;
   
   graph->edge[25].src = 16;//q
   graph->edge[25].dest = 17;//r
   graph->edge[25].weight = 2;
   
   graph->edge[26].src = 16;//q
   graph->edge[26].dest = 18;//s
   graph->edge[26].weight = 4;
   
   graph->edge[27].src = 17;//r
   graph->edge[27].dest = 12;//m
   graph->edge[27].weight = 2;
   
   graph->edge[28].src = 18;//s
   graph->edge[28].dest = 19;//t
   graph->edge[28].weight = 1;
   
   graph->edge[30].src = 7;//h
   graph->edge[30].dest = 12;//m
   graph->edge[30].weight = 4;
   
      
   graph->edge[61].src = 19;//t
   graph->edge[61].dest = 0;//a
   graph->edge[61].weight = 100;

   //end of our first graph
   
   //below is still shit they did i used for reference
   
    // add edge 0-1 (or A-B in above figure)
    /*graph->edge[0].src = 0;
    graph->edge[0].dest = 1;
    graph->edge[0].weight = -1;
 
    // add edge 0-2 (or A-C in above figure)
    graph->edge[1].src = 0;
    graph->edge[1].dest = 2;
    graph->edge[1].weight = 4;
 
    // add edge 1-2 (or B-C in above figure)
    graph->edge[2].src = 1;
    graph->edge[2].dest = 2;
    graph->edge[2].weight = 3;
 
    // add edge 1-3 (or B-D in above figure)
    graph->edge[3].src = 1;
    graph->edge[3].dest = 3;
    graph->edge[3].weight = 2;
 
    // add edge 1-4 (or A-E in above figure)
    graph->edge[4].src = 1;
    graph->edge[4].dest = 4;
    graph->edge[4].weight = 2;
 
    // add edge 3-2 (or D-C in above figure)
    graph->edge[5].src = 3;
    graph->edge[5].dest = 2;
    graph->edge[5].weight = 5;
 
    // add edge 3-1 (or D-B in above figure)
    graph->edge[6].src = 3;
    graph->edge[6].dest = 1;
    graph->edge[6].weight = 1;
 
    // add edge 4-3 (or E-D in above figure)
    graph->edge[7].src = 4;
    graph->edge[7].dest = 3;
    graph->edge[7].weight = -3;*/
 
    BellmanFord(graph, 0);
 
    return 0;
}

// Source: http://www.geeksforgeeks.org/dynamic-programming-set-23-bellman-ford-algorithm/